export class Games {
    constructor(
      public id: string,
      public title: string,
      public image: string,
      public releaseDate: Date,
      public genre:string
    ){}
    }